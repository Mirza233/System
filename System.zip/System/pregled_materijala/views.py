from django.shortcuts import render
from .models import Materijali
from .forms import MaterijaliForm

def index(request):
	materijali = Materijali.objects.filter(active=1)
	print(request.user)
	form = MaterijaliForm(request.POST or None)
	if form.is_valid():
		form.save()
	return render(request,'index.html', {'all':materijali,'form':form,})
