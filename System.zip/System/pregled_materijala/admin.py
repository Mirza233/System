from django.contrib import admin

from .models import *

admin.site.register(Materijali)
admin.site.register(Proizvodi)
admin.site.register(Detalji)
admin.site.register(Proizvodnja)
admin.site.register(Narudzba)