from django.db import models

class Proizvodi(models.Model):
	sifra_proizvoda = models.CharField(max_length = 30)
	naziv_proizvoda = models.CharField(max_length = 60)
	stanje_proizvodnja = models.CharField(max_length = 100, default = "")
	stanje_prodaja = models.CharField(max_length = 100, default = "")
	stanje_montaza = models.CharField(max_length = 100, default = "")
	active = models.IntegerField(default=1)
	def __str__(self):
		return self.naziv_proizvoda

class Materijali(models.Model):
	sifra_materijala = models.CharField(max_length = 20)
	naziv_materijala = models.CharField(max_length = 50, unique=True)
	kolicina = models.IntegerField(default = 0)
	active = models.IntegerField(default=1)
	def __str__(self):
		return self.naziv_materijala

class Detalji(models.Model):
	proizvod = models.ForeignKey(Proizvodi,on_delete=models.CASCADE)
	materijal = models.ForeignKey(Materijali,on_delete=models.CASCADE)
	kolicina = models.IntegerField()
	def __str__(self):
		return str(self.kolicina) + " " + self.materijal.naziv_materijala + "/" + self.proizvod.naziv_proizvoda

class Proizvodnja(models.Model):
	proizvod = models.ForeignKey(Proizvodi,on_delete=models.CASCADE)
	kolicina = models.IntegerField()
	def __str__(self):
		return str(self.kolicina) + " " + self.proizvod.naziv_proizvoda

class Narudzba(models.Model):
	materijal = models.ForeignKey(Materijali,on_delete=models.CASCADE)
	kolicina = models.IntegerField()
	def __str__(self):
		return str(self.kolicina) + " " + self.proizvod.naziv_proizvoda
