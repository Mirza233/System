from django.forms import ModelForm, ValidationError
from .models import Materijali

class MaterijaliForm(ModelForm):
	error_css_class = 'text-danger'
	class Meta:
		model = Materijali
		fields = ["naziv_materijala","kolicina"]
		error_messages = {
			      'naziv_materijala': {
			        			   'unique': ("Materijal sa tim nazivom vec postoji u bazi"),
			    				 },
			     }
	def clean_kolicina(self):
		kolicina = self.cleaned_data.get('kolicina')
		if kolicina<0:
			raise ValidationError("Količina ne moze biti negativna")
		return kolicina

	def clean_naziv_materijala(self):
		naziv_materijala = self.cleaned_data.get('naziv_materijala')
		naziv_materijala = naziv_materijala.strip()
		queryset = list(map(lambda x:x.naziv_materijala.lower(),list(Materijali.objects.all())))
		if naziv_materijala.lower() in queryset:
			raise ValidationError("Materijal prethodno dodan u bazu")
		return naziv_materijala


